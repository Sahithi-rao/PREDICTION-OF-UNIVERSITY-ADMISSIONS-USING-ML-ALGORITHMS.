# PREDICTION-OF-UNIVERSITY-ADMISSION-USING-REGRESSION-ANALYSIS
It is a Machine Learning project where we was given a data set and we used few regression techniques and some graphical plots and predicted on what inputs university admissions mostly depend.
